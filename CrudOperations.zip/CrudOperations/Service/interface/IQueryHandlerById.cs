﻿namespace CrudOperations.Service
{
    public interface IQueryHandlerById<TQuery, TResult>
    {

    }
}
