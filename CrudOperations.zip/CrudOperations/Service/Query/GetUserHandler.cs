﻿using CrudOperations.Models;
using CrudOperations.Models.DTO;
using Microsoft.EntityFrameworkCore;


namespace CrudOperations.Service.Query
{
    public class GetUserHandler : IQueryHandler<GetUserQuery, List<UserDTO>>
    {

        private BrandContext _dbContext;

        public GetUserHandler(BrandContext brandContext)
        {
            _dbContext = brandContext;
        }


        public List<UserDTO> Handle(GetUserQuery query)
        {



            List<UserDTO> users = _dbContext.Users
                        .Include(u => u.Brand)
                        .Select(u => new UserDTO
                        {
                            Id = u.Id,
                            Name = u.Name,
                            DeviceId = u.DeviceId,
                            Brand = new BrandSimpleDTO()
                            {
                                DeviceId = u.Brand.DeviceId,
                                Name = u.Brand.Name
                            }

                        })
                        .ToList();

         




            return users;
        }

        
    }
}
