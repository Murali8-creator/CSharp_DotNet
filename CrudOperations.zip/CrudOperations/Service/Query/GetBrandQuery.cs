﻿using CrudOperations.Models;

namespace CrudOperations.Service.Query
{
    public class GetBrandQuery : Brand
    {

    }
}
