﻿using CrudOperations.Models;
using CrudOperations.Models.DTO;
using Microsoft.EntityFrameworkCore;


namespace CrudOperations.Service.Query
{
    public class GetBrandHandler : IQueryHandler<GetBrandQuery, List<BrandDTO>>
    {
        private readonly BrandContext _dbContext;

        public GetBrandHandler(BrandContext brandContext)
        {
            _dbContext = brandContext;
        }

        public List<BrandDTO> Handle(GetBrandQuery query)
        {
            
            List<UserSimpleDTO> usersList = new List<UserSimpleDTO>();

            List<BrandDTO> brands = _dbContext.Brands
                .Include(b => b.Users)
                .Select(b => new BrandDTO
                {
                    DeviceId = b.DeviceId,
                    Name = b.Name,
                    Users = b.Users.Select(u => new UserSimpleDTO
                    {
                        Id = u.Id,
                        Name = u.Name
                    }).ToList()
                })
                .ToList();

            return brands;
        }
    }
}
