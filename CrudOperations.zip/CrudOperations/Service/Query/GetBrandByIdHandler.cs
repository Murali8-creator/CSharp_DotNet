﻿using CrudOperations.Models;
using Microsoft.EntityFrameworkCore;

namespace CrudOperations.Service.Query
{
    public class GetBrandByIdHandler : IQueryHandler<GetBrandQuery, Brand>
    {

        private readonly BrandContext _brandContext;

        public GetBrandByIdHandler(BrandContext brandContext)
        {
            _brandContext = brandContext;
        }

        public Brand Handle(GetBrandQuery query)
        {
            var brand = _brandContext.Brands.Find(query.DeviceId); 
            if (brand == null)
            {
                throw new Exception("Brand not found"); 
            }
            return brand; 
        }
    }
}
