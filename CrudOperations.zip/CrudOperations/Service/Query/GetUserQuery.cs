﻿using CrudOperations.Models;

namespace CrudOperations.Service.Query
{
    public class GetUserQuery : User
    {
    }
}
