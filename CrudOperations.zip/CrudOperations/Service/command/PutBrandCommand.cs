﻿using CrudOperations.Models;

namespace CrudOperations.Service.command
{
    public class PutBrandCommand : Brand
    {

    }
}
