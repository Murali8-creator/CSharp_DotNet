﻿using CrudOperations.Models;
using Microsoft.EntityFrameworkCore;

namespace CrudOperations.Service.command
{
    public class DeleteBrandHandler : ICommandHandler<DeleteBrandCommand>
    {
        private readonly BrandContext _dbContext;

        public DeleteBrandHandler(BrandContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Handle(DeleteBrandCommand command)
        {
            var brand = _dbContext.Brands.Find(command.DeviceId);

            if (brand == null)
            {
                // Handle the case when the entity is not found
                throw new InvalidOperationException("Brand not found.");
            }

            _dbContext.Brands.Remove(brand);
            int res = _dbContext.SaveChanges();
            return res;
        }
    }
}
