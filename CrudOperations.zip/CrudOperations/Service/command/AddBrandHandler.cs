﻿using CrudOperations.Models;

namespace CrudOperations.Service.command
{
    public class AddBrandHandler : ICommandHandler<AddBrandCommand>
    {
        
        private readonly BrandContext _dbContext;

        public AddBrandHandler(BrandContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Handle(AddBrandCommand command)
        {

            _dbContext.Brands.Add(command);
            

            int res = _dbContext.SaveChanges();

            return res;
        }

    }
}
