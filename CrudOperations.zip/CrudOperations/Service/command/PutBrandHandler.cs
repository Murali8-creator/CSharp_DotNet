﻿using CrudOperations.Models;
using Microsoft.EntityFrameworkCore;

namespace CrudOperations.Service.command
{
    public class PutBrandHandler : ICommandHandler<PutBrandCommand>
    {
        private readonly BrandContext _dbContext;

        public PutBrandHandler(BrandContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Handle(PutBrandCommand brand)
        {
            //throw new NotImplementedException();
            _dbContext.Entry(brand).State = EntityState.Modified;
            try
            {
                _dbContext.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                return 0;
            }
            return 1;
        }


        private bool BrandAvailable(int id)
        {
            return (_dbContext.Brands?.Any(x => x.DeviceId == id)).GetValueOrDefault();
        }

    }
}
