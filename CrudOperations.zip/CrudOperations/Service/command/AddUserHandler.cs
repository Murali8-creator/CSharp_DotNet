﻿using CrudOperations.Models;

namespace CrudOperations.Service.command
{
    public class AddUserHandler : ICommandHandler<AddUserCommand>
    {
        private readonly BrandContext _dbContext;

        public AddUserHandler(BrandContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Handle(AddUserCommand command)
        {
            var user = new User
            {
                Name = command.Name,
                DeviceId = command.DeviceId
            };

            _dbContext.Users.Add(user);
            try
            {
                _dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return 0;
            }

            return 1;
        }
    }
}
