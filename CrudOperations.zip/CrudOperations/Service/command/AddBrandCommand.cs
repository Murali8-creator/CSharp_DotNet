﻿using CrudOperations.Models;

namespace CrudOperations.Service.command
{
    public class AddBrandCommand : Brand
    {

    }
}
